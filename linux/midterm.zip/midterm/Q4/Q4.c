#include <stdio.h>
#include <stdlib.h>
#include "lib.h"
int main(){
    int  n;
    printf("输入整数n:");
    scanf("%d",&n);
    float array[n]; 
    for( int i=0 ; i<n ; i++ ){
        array[i] = (float)((rand() % 100) + 100);
    }
    float avg = secendMax(array,n);
    float deviation = getDeviation(array,n);
    printf("第二大的值为 %4.2f\n",avg);
    printf("平均差为 %4.2f\n",deviation);
    return 0;
}