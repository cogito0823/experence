#include <stdio.h>

float secendMax(float *a,int size){
    float max, second;
    max = 0;
    second = 0;
    for(int i = 0; i < size; i++)
    {
        if (a[i] > max)
        {
            second = max;        //先把原来的最大数给第二大数
            max = a[i];          //再刷新最大数
        }
        else if (a[i] > second)
            second = a[i];       //第二大的数
    }
    return second;
}
