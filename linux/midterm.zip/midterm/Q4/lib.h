float secendMax(float *a,int size);
float getDeviation(float *a,int size);