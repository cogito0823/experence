#include <stdio.h>
#include<math.h>

float getDeviation(float *a,int size){
    float sum = 0,avg;
    int i;
    for(i=0;i<size;i++){
        sum += a[i];
    }
    avg=sum/size;
    float temp=0;
    float Spow=0;
    for(i=0;i<size;i++){
        Spow+=(a[i]-avg)*(a[i]-avg);
    }
    return Spow/size;
}