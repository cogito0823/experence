#!/bin/bash
# author: yuxin.yu
index=0
array1=()
array2=()
res=()
for item in $@
do  
    if [ $index -lt 6 ]
    then
        array1[$index]=$item
    else 
        array2[`expr $index - 6`]=$item    
    fi
    index=`expr $index + 1`
done

for i in "${!array1[@]}"
do
    res[$i]="`expr ${array1[$i]} + ${array2[$i]}`"
done

true > ./Q2_result.txt
echo ${array1[@]} >> ./Q2_result.txt
echo ${array2[@]} >> ./Q2_result.txt
echo ${res[@]} >> ./Q2_result.txt