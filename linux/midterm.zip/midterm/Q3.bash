#!/bin/bash
# author: yuxin.yu
echo "please enter a integer n ->"
read n

signal=1
index=1
sum=0
while [ $index -le $n ]
do
    tmp=`echo "scale=3;1/$index"|bc`
    tmp=`echo "scale=3;$signal*$tmp"|bc`
    sum=`echo "scale=3;$sum+$tmp"|bc`
    let signal=signal*-1
    let index++  
done

echo "$sum"