#!/bin/bash

if [ $# -eq 1 ]
then 
    if [ -d $1 ]
    then 
        ls -Rl $1
    elif [ -f $1 ]
    then
        ls -l $1
    else 
        echo 'argument is not a dictionary or a file'
    fi
else
    echo 'arguments num great than 1' 
fi
