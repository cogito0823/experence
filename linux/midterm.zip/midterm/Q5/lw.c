count-word-with-buffer.c
/**
 * file  : read-word-with-buffer.c
 * date  : 2019-04-24
 * author: netuxi
 */

#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
// #include <string.h>
#include "word.h"

int main(int argc, char **argv)
{
    FILE *fp;
    if ((fp = fopen("wordCount.txt", "r")) == NULL) {
        printf("failed to open file\n");
        exit(1);
    }

    struct WORD *word = NULL, *end = NULL;
    int notfinish = 1, i, isalpha, wordnum = 0;
    while (notfinish) {
        i = 0, isalpha = 1;
        char buf[16] = {0};
        while (isalpha) {
            char ch = fgetc(fp);
            if (ch == EOF && i < 1) {
                notfinish = 0;
                break;
            } else if (ch == EOF && i >= 1) {
                /* set the finish flag */
                notfinish = 0;

                /* build a WORD */
                struct WORD *tmp = search(word, buf);
                if (tmp == NULL) {
                    tmp = buildword(buf);
                    if (word == NULL) {
                        word = tmp;
                        end = tmp;
                    } else {
                        (*end).next = tmp;
                        end = (*end).next;
                    }
                    wordnum++;
                } else {
                    (*tmp).number = (*tmp).number + 1;
                }

                /* quit read word loop */
                break;
            } else if (isalpha(ch)) {
                // printf("execute 3 with %c\n", ch);
                /* continue read word */
                buf[i++] = ch;
            } else if (i > 0) {
                /* finish read a word */
                // printf("execute 4 with %c\n", ch);

                /* build a WORD */
                struct WORD *tmp = search(word, buf);
                if (tmp == NULL) {
                    tmp = buildword(buf);
                    if (word == NULL) {
                        word = tmp;
                        end = tmp;
                    } else {
                        (*end).next = tmp;
                        end = (*end).next;
                    }
                    wordnum++;
                } else { 
                    (*tmp).number = (*tmp).number + 1;
                }

                isalpha = 0;
                break;
            }
        }
    }

    printf("wordnum => %d\n", wordnum);
    i = 0;
    for (struct WORD *tmp = word; tmp != NULL; tmp = (*tmp).next) {
        printf("%-16s|%-4d", (*tmp).content, (*tmp).number);
        if (i++ % 5 == 4) {
            printf("\n");
        }
    }
    printf("\n");

    while (word != NULL) {
        struct WORD *tmp = (*word).next;
        free(word);
        word = tmp;
    }

    return 0;
}