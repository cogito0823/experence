#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>


struct WORD {
    char content[16];
    int number;
    struct WORD *next;
};

/* build a word */
struct WORD * buildword(char *buf)
{
    struct WORD *tmp = (struct WORD *)malloc(sizeof(struct WORD));
    if (tmp == NULL) {
        printf("malloc error");
        exit(1);
    }
    strcpy((*tmp).content, buf);
    (*tmp).number = 1;
    (*tmp).next = NULL;

    return tmp;
}

/* search the word */
struct WORD* search(struct WORD *word, const char *buf)
{
    struct WORD *tmp = word;
    while (tmp != NULL) {
        if (strcmp((*tmp).content, buf) == 0) {
            return tmp;
        }
        tmp = (*tmp).next;
    }

    return NULL;
}