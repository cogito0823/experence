#include<stdio.h>
#include<stdlib.h>
#include<fcntl.h>
#include<string.h>
#include<unistd.h>
#include<ctype.h>
#include "word.h"

int main(){
    char passage[1000];
    char txt[1000];
    memset(passage,0,1000);
    FILE *fp = fopen("./wordCount.txt","r");
    while(fgets(txt,1000,fp) != NULL){
		strcat(passage,txt);
    }
    
    int isApla = 0;
    char str[15]; 
    int index = 0;
    struct WORD *start = buildword(" ");
    struct WORD *end = start;
    
    for(int i = 0; i < 1000 ; i++)
    {
        if(isalpha(passage[i])){
            isApla = 1;
            str[index] = passage[i];
            index++; 
        }else if(isApla == 1){
            isApla=0;
            index=0;
            //寻找链表中是否存在该单词
            struct WORD *tmp = search(start,str);
            if(tmp == NULL){
               tmp = buildword(str); 
               (*end).next = tmp;
               end = (*end).next; 
            }else{
                (*tmp).number += 1;
            }
            memset(str,0,15);
        }
    }
    struct WORD *word = (*start).next;
    while( word != NULL){
        printf("%s : %d \n",(*word).content,(*word).number);
        word = (*word).next;
    }
    fclose(fp);

}


